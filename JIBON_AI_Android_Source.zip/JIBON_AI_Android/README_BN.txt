JIBON AI 2.1 — Android Studio সোর্স প্রজেক্ট

এই ZIP-এ Android অ্যাপের সোর্স কোড আছে। এটি এখনো APK ফাইল নয়।

যা আছে:
- JIBON AI 2.1-এর অ্যানিমেটেড বাংলা ইন্টারফেস
- Android-এর নিজস্ব microphone permission prompt
- Android SpeechRecognizer দিয়ে বাংলা (bn-BD) ভয়েস ইনপুট
- Android TextToSpeech দিয়ে বাংলা ভয়েস আউটপুট (ফোনে বাংলা TTS voice থাকলে)
- Facebook, YouTube ও Google লিংক বাইরের অ্যাপে/ব্রাউজারে খোলে

APK বানাতে:
1. কম্পিউটারে Android Studio ইনস্টল করো।
2. ZIP Extract করো।
3. Android Studio > Open > JIBON_AI ফোল্ডার বেছে নাও।
4. Gradle sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপো।
5. Build সফল হলে app/build/outputs/apk/debug/app-debug.apk পাওয়া যাবে।

প্রয়োজন: Android Studio, JDK 17, Android SDK Platform 35 এবং ইন্টারনেট (প্রথম Gradle sync-এর জন্য)।

সীমাবদ্ধতা: এই সংস্করণে সাধারণ প্রশ্নের উত্তর দেওয়ার পূর্ণ AI backend নেই। ভয়েস শনাক্তকরণ ও বাংলা TTS ফোনের Google speech service, ভাষা প্যাক এবং ইন্টারনেটের ওপর নির্ভর করতে পারে।

কম্পিউটার না থাকলে GitHub Actions দিয়েও বিল্ড করা যাবে:
1. GitHub-এ নতুন একটি repository তৈরি করো।
2. এই ZIP-এর ভেতরের ফাইলগুলো repository-তে upload করো (ফোল্ডারের ভেতরের সব ফাইলসহ)।
3. Actions ট্যাবে গিয়ে “Build JIBON AI APK” workflow চালাও (অথবা main branch-এ push করলেই চলবে)।
4. সফল হলে workflow run-এর Artifacts অংশ থেকে JIBON-AI-debug-APK ZIP ডাউনলোড করো; তার ভেতরে app-debug.apk থাকবে।
